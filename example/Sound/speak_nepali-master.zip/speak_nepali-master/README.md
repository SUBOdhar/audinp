# speak_nepali
### nepali text to speech app 

*Sound files are originally from [meamit/nepali-text-to-speech](https://github.com/meamit/nepali-text-to-speech)*
  (sound files are being updated)
  
# USAGE
```
python speak_nepali.py "के छ"
```
# DEPEDENCIES
- pyaudio
  `pip install pyaudio`
- pyaudio requires portaudio.h
  `apt install portaudio-19.dev`
